package com.user.service;

import java.util.Optional;

import com.user.model.Add;
import com.user.model.User;
import com.user.model.Valid;

public interface RegisterService {
	public void saveData(User user,Add add,Valid valid);
	public boolean authenticate(Valid valid);
	public boolean authenticate1(String emailid);
	public User getUser(String email);
	public Add getAdd(String email);
	public Valid getValid(String email);
	
	
	
	
	public void deleteData(Valid valid);
	public Optional<User> search(String emailid);
	public void saveUpdate(User user);
}

package com.user.frontend;

public class Use {

	public int name(String firstName2) {
		// TODO Auto-generated method stub
				int value=1;
				if(firstName2.toString().length()==0)
					value=0;
				return value;
				// TODO Auto-generated method stub
				
	}
	
	public int lastname(String LastName) {
		// TODO Auto-generated method stub
				int value=1;
				if(LastName.toString().length()==0)
					value=0;
				return value;
				// TODO Auto-generated method stub
				
	}
	
	public int phone(String phonenumber) {
		// TODO Auto-generated method stub
				int value=1;
				if(phonenumber.toString().length()!=10)
					value=0;
				return value;
				// TODO Auto-generated method stub
				
	}
	
	public int pincode(String pincode) {
		// TODO Auto-generated method stub
				int value=1;
				if(pincode.toString().length()!=6)
					value=0;
				return value;
				// TODO Auto-generated method stub
				
	}
	
	public int password(String password) {
		// TODO Auto-generated method stub
				int value=1;
				if(password.toString().length()<7)
					value=0;
				return value;
				// TODO Auto-generated method stub
				
	}
	
	public int confirm(String password,String confirm) {
		// TODO Auto-generated method stub
				int value=1;
				if(!password.equals(confirm))
					value=0;
				return value;
				// TODO Auto-generated method stub
				
	}
	public int Email() {
	ValidatingEmail register=new ValidatingEmail();
	 return register.valid();
	}
}

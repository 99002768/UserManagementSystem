package com.user.frontend;

import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.directory.SearchResult;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.user.model.Add;
import com.user.model.User;
import com.user.model.Valid;
import com.user.service.RegisterService;
import com.user.service.RegisterServiceImpl;

//@Component
public class Registration {

	@Autowired
    RegisterService registerservice;

//	@Autowired(required=true)
	
    User user=new User();
    Add  add=new Add();
    Valid valid=new Valid();
    
	private JFrame frame;
		private JTextField id;
	    private JTextField firstname;
	    private JTextField lastname;
	    private JTextField middlename;
	    private JTextField email;
	    private JTextField mobilenumber;
	    private JComboBox state;
	    private JTextField city;
	    private JTextField pincode;
	    private JRadioButton gender;
	    private JRadioButton gender1;
	    private JTextField adhar;
	    private JTextField country;
	    private JPasswordField passwordField;
	    private JPasswordField passwordFieldConfirm;
	    int x =0;
	    int source=0;
	    private JButton btnNewButton;
	    int flag=1;
	    int need=0;
	    
	    private JTextField firstnameerror;
		private JTextField textField;
		private JPasswordField passwordFieldLogin;
		private BufferedImage img;
		static JTable table;
		
		private JTextField textField0;
		private JTextField textField_1;
		private JTextField textField_2;
		private JTextField textField_3;
		DefaultTableModel model;
		
		   JLabel firsterror ;
		   JLabel  seconderror;
		   JLabel  thirderror;
		   JLabel  fourtherror;
		   JLabel  sixtherror;
		   JLabel sevenerror;
	    /**
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Registration window = new Registration();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Registration() {
		initializeLand();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		System.out.println("i am in user");
		
		frame = new JFrame();
		Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\Training\\Desktop\\avatar1.png");  
		frame.setIconImage(icon); 
		frame.setBounds(450, 190, 1500, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().setBackground(Color.getHSBColor(188, 66, 93));
		frame.setVisible(true);
		
		JLabel lblNewUserRegister = new JLabel(" User Registration");
        lblNewUserRegister.setFont(new Font("Times New Roman", Font.PLAIN, 42));
        lblNewUserRegister.setBounds(495, 51, 325, 50);
        lblNewUserRegister.setBackground(Color.blue);
        frame.getContentPane().add(lblNewUserRegister);

        JLabel lblName = new JLabel("First Name*");
        lblName.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblName.setBounds(50, 150, 150, 50);
        frame.getContentPane().add(lblName);
       
        firstname = new JTextField();
        firstname.setFont(new Font("Tahoma", Font.PLAIN, 32));
        firstname.setBounds(200, 150, 230, 50);
        frame.getContentPane().add(firstname);
        firstname.setColumns(10);
        
        String reg="[a-zA-z]+([ '-][a-zA-Z]+)*.{2,20}\"";
        
        firsterror = new JLabel("please enter first name");
        firsterror.setForeground(Color.RED);
        firsterror.setBounds(200, 200, 232, 14);
        firsterror.setVisible(false);
        frame.getContentPane().add(firsterror);
        
    	firstname.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				 Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
				 firstname.setBorder(border);
			}
			@Override
			public void focusLost(FocusEvent e) {
			// TODO Auto-generated method stub
				error();
				if((firstname.getText().length() == 0 )) {
					firsterror.setVisible(true);
					  Border border = BorderFactory.createLineBorder(Color.RED, 1);
					firstname.setBorder(border);
					
	                }

							
			}
		});
    	
    	
    	  firstname.addKeyListener(new KeyAdapter() {
    		  Pattern pattern = Pattern.compile(reg);
              Matcher matcher = pattern.matcher(firstname.getText());
              @Override
              public void keyTyped(KeyEvent e) {
                  char c=e.getKeyChar();
                 
				if((Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE)|| c==KeyEvent.VK_DELETE||firstname.getText().length()>=25)) {
                      e.consume();
                  }
                  if((firstname.getText() == null)) {
  					firsterror.setVisible(true);
  					flag=0;
  	                }
  				else {
  					firsterror.setVisible(false);
  					flag=1;
  				}
              }
    	  	@Override
    	  	public void keyReleased(KeyEvent e) {
    	  		 if(!matcher.matches()) {
   					e.consume();
   	                }

    	  	}
    	  	
          });
       
       
        JLabel lblmiddlename = new JLabel("Middle Name");
        lblmiddlename.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblmiddlename.setBounds(500, 150, 200, 50);
        frame.getContentPane().add(lblmiddlename);
       
        middlename = new JTextField();
        middlename.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		char c=e.getKeyChar();
                if((Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE)|| c==KeyEvent.VK_DELETE||middlename.getText().length()>=25)) {
                    e.consume();
                }
        	}
        });
        middlename.setFont(new Font("Tahoma", Font.PLAIN, 32));
        middlename.setBounds(700, 150, 230, 50);
        frame.getContentPane().add(middlename);
        middlename.setColumns(10);
       
       
       
        JLabel lblNewLabel = new JLabel("Last Name*");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel.setBounds(1000, 150, 150, 50);
        frame.getContentPane().add(lblNewLabel);
       
        lastname = new JTextField();
        lastname.setFont(new Font("Tahoma", Font.PLAIN, 32));
        lastname.setBounds(1125, 150, 230, 50);
        frame.getContentPane().add(lastname);
        lastname.setColumns(10);
        
        
        seconderror = new JLabel("please enter last name");
        seconderror.setBounds(1125, 200, 232, 14);
        frame.getContentPane().add(seconderror);
    	seconderror.setVisible(false);
       
    	lastname.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				 Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
				 lastname.setBorder(border);
			}
			@Override
			public void focusLost(FocusEvent e) {
			// TODO Auto-generated method stub
				error();
				if((lastname.getText().length() == 0 )) {
					seconderror.setVisible(true);
					Border border = BorderFactory.createLineBorder(Color.RED, 1);
					lastname.setBorder(border);
					seconderror.setForeground(Color.red);
                          
	                }
				

				
			}
		});
    	
    	  lastname.addKeyListener(new KeyAdapter() {
              @Override
              public void keyTyped(KeyEvent e) {
                  char c=e.getKeyChar();
                  if((Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE)|| c==KeyEvent.VK_DELETE||lastname.getText().length()>=25)) {
                      e.consume();
                  }
                  if((lastname.getText().toString() == null)) {
  					seconderror.setVisible(true);
  					flag=1;
  	                }
                  
  				else {
  					seconderror.setVisible(false);
  					flag=0;
  				}

              }
    	  	@Override
    	  	public void keyReleased(KeyEvent e) {
    	  		 char c=e.getKeyChar();
    	  		if((c==KeyEvent.VK_BACK_SPACE)) {

                }
    	  	}
          });
         	  
        JLabel lblEmailAddress = new JLabel("Email\r\n Address*");
        lblEmailAddress.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblEmailAddress.setBounds(50, 255, 150, 36);
        frame.getContentPane().add(lblEmailAddress);
       
        email = new JTextField();
        email.setFont(new Font("Tahoma", Font.PLAIN, 32));
        email.setBounds(200, 250, 228, 50);
        frame.getContentPane().add(email);
        email.setColumns(10);

        thirderror = new JLabel("please enter valid email id");
        thirderror.setForeground(Color.RED);
        thirderror.setBounds(200, 300, 230, 14);
        frame.getContentPane().add(thirderror);
        thirderror.setVisible(false);
        
        String EMAIL_REGEX = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        
        email.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				 Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
				 email.setBorder(border);
			}
			@Override
			public void focusLost(FocusEvent e) {
			// TODO Auto-generated method stub
				error();
				if((!email.getText().matches(EMAIL_REGEX))) {

					thirderror.setVisible(true);
					  Border border = BorderFactory.createLineBorder(Color.RED, 1);
					email.setBorder(border);
					thirderror.setForeground(Color.red);
					System.out.println(email.getText());
	                }
				if(registerservice.authenticate1(email.getText())) {
					JOptionPane.showMessageDialog(null, "user exists please choose another email");
					need=1;
				}
				else {
					need=0;
				}
				

			}
		});
    	
    	  email.addKeyListener(new KeyAdapter() {
              @Override
              public void keyTyped(KeyEvent e) {
            	  if(email.getText().length()>=50) {
                      e.consume();
                  }
                  if((email.getText() == null)) {
  					thirderror.setVisible(true);
  					flag=0;
  	                }
                  if((!email.getText().matches(EMAIL_REGEX))) {
  					thirderror.setVisible(false);
  					flag=1;
  				}
              }
          });
        
        
       
        JLabel lblMobileNumber = new JLabel("Mobile Number*");
        lblMobileNumber.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblMobileNumber.setBounds(500, 260, 150, 26);
        frame.getContentPane().add(lblMobileNumber);

        mobilenumber = new JTextField();
        mobilenumber.setFont(new Font("Tahoma", Font.PLAIN, 32));
        mobilenumber.setBounds(700, 250, 228, 50);
        frame.getContentPane().add(mobilenumber);
        mobilenumber.setColumns(10);
     	
      fourtherror = new JLabel("please enter mobile number");
        fourtherror.setForeground(Color.RED);
        fourtherror.setBounds(700, 300, 230, 14);
        frame.getContentPane().add(fourtherror);
        fourtherror.setVisible(false);
        
        
        mobilenumber.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				 Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
				 mobilenumber.setBorder(border);
				
			}
			@Override
			public void focusLost(FocusEvent e) {
			// TODO Auto-generated method stub
				error();
				 if (mobilenumber.getText().length() != 10) {
					 fourtherror.setVisible(true);
					  Border border = BorderFactory.createLineBorder(Color.RED, 1);
					mobilenumber.setBorder(border);
					fourtherror.setForeground(Color.red);
					
                 }
				

				 
			}
		});

        mobilenumber.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c=e.getKeyChar();
                if(!(Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE)|| c==KeyEvent.VK_DELETE)) {
                    e.consume();
                }
                if(mobilenumber.getText().length()!=10) {
                    fourtherror.setVisible(true);
                }
               
                else if(mobilenumber.getText().length()>=10) {
                     JOptionPane.showMessageDialog(lblMobileNumber, "please enter 10 digits only");
                     fourtherror.setVisible(false);
                     e.consume();
                 }
            }
        	@Override
        	public void keyReleased(KeyEvent e) {
        		 if(mobilenumber.getText().length()==10) {
                     fourtherror.setVisible(false);
                 }

        	}
        });
       
        
        
        JLabel genderEnter=new JLabel("Gender*");
        genderEnter.setFont(new Font("Tahoma",Font.PLAIN,20));
        genderEnter.setBounds(1000,250,123,45);
        frame.getContentPane().add(genderEnter);
     
        gender = new JRadioButton();
        gender.setText("Male");
        gender.setFont(new Font("Tahoma", Font.PLAIN, 20));
        gender.setBounds(1125, 250, 100, 50);
        frame.getContentPane().add(gender);
       
        gender1 = new JRadioButton();
        gender1.setText("Female");
        gender1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        gender1.setBounds(1250, 250, 100, 50);
        frame.getContentPane().add(gender1);
     
        ButtonGroup bg = new ButtonGroup(); 
        bg.add(gender); 
        bg.add(gender1); 
        
        
       
        JLabel lblstate = new JLabel("State");
        lblstate.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblstate.setBounds(50, 465, 99, 24);
        frame.getContentPane().add(lblstate);
    String s1[] = {	"select",
    							"AP",
                                "Arunachal",
                                "Assam",
                                "Bihar",
                                "Chhattisgarh",
                                "Goa",
                                "Gujarat",
                                "Haryana",
                                "HimachalPradesh",
                                "Jammu",
                                "Jharkhand",
                                "Karnataka",
                                "Kerala",
                                "MadhyaPradesh",
                                "Maharashtra",
                                "Manipur",
                                "Meghalaya",
                                "Mizoram",
                                "Nagaland",
                                "Odisha",
                                "Punjab",
                                "Rajasthan",
                                "Sikkim",
                                "Tamil Nadu",
                                "Telangana",
                                "Tripura",
                                "Uttarakhand",
                                "Uttar Pradesh",
                                "West Bengal",
                                "Andaman ",
                                "Chandigarh",
                                "Dadra",
                                "Daman and Diu",
                                "Delhi",
                                "Lakshadweep",
                                "Puducherry"};
       
        state = new JComboBox(s1);
        state.setFont(new Font("Tahoma", Font.PLAIN, 32));
        state.setBounds(200, 450, 230, 50);
        frame.getContentPane().add(state);
        System.out.println(state.getSelectedItem());
       
       
        JLabel lblCity = new JLabel("City");
        lblCity.setFont(new Font("Tahoma",Font.PLAIN,20));
        lblCity.setBounds(1000,350,123,45);
        frame.getContentPane().add(lblCity);
       
        city = new JTextField();
        city.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		char c=e.getKeyChar();
                if((Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE)|| c==KeyEvent.VK_DELETE||city.getText().length()>=12)) {
                    e.consume();
                }
        	}
        });
        
        city.setFont(new Font("Tahoma", Font.PLAIN, 32));
        city.setBounds(1125, 350, 228, 50);
        frame.getContentPane().add(city);
        city.setColumns(10);
       
        JLabel lblpin = new JLabel("PinCode");
        lblpin.setFont(new Font("Tahoma",Font.PLAIN,20));
        lblpin.setBounds(1000,450,123,45);
        frame.getContentPane().add(lblpin);
       
        pincode = new JTextField();
        pincode.setFont(new Font("Tahoma", Font.PLAIN, 32));
        pincode.setBounds(1125, 450, 228, 50);
        frame.getContentPane().add(pincode);
        pincode.setColumns(10);

        pincode.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c=e.getKeyChar();
                if(!(Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE)|| c==KeyEvent.VK_DELETE)) {
                    e.consume();
                }
                else if(pincode.getText().length()>=6) {
                     JOptionPane.showMessageDialog(lblMobileNumber, "please enter 6 digits only");
                     e.consume();
                 }
            }
        });

        
        
        JLabel countrylbl = new JLabel("Country");
        countrylbl.setFont(new Font("Tahoma",Font.PLAIN,20));
        countrylbl.setBounds(500, 450, 228, 50);
        frame.getContentPane().add(countrylbl);
       
        country = new JTextField();
        country.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		char c=e.getKeyChar();
                if(((c==KeyEvent.VK_BACK_SPACE)|| c==KeyEvent.VK_DELETE||country.getText().length()>=12)) {
                    e.consume();
                }
        	}
        });
        country.setFont(new Font("Tahoma", Font.PLAIN, 32));
        country.setBounds(700, 450, 228, 50);
        frame.getContentPane().add(country);
        country.setColumns(10);

        
        JLabel lblPassword = new JLabel("Password*");
        lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblPassword.setBounds( 50, 360, 99, 24);
        frame.getContentPane().add(lblPassword);
        
        
     
        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Tahoma", Font.PLAIN, 32));
        passwordField.setBounds(200, 350, 230, 50);
        frame.getContentPane().add(passwordField);

        
        sixtherror = new JLabel("please enter minimum 8 digit password");
        sixtherror.setForeground(Color.RED);
        sixtherror.setBounds(200, 400, 232, 14);
        frame.getContentPane().add(sixtherror);
        sixtherror.setVisible(false);
        
         String regex = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})";
                
        
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(passwordField.getText());
        
        
        passwordField.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				 Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
				 passwordField.setBorder(border);
			}
			@Override
			public void focusLost(FocusEvent e) {
			// TODO Auto-generated method stub
				error();
				if( (passwordField.getText().length()<8)) {

					 sixtherror.setVisible(true);
					  Border border = BorderFactory.createLineBorder(Color.RED, 1);
					  passwordField.setBorder(border);
					  sixtherror.setForeground(Color.red);
					 
	                }
			
//					valid();
			}
		
		});
    	
        passwordField.addKeyListener(new KeyAdapter() {
              @Override
              public void keyReleased(KeyEvent e) {
                 
                  if(( passwordField.getText() == null)) {
                	  sixtherror.setVisible(true);
                	  flag=0;
  	                }
                  if((passwordField.getText().length()>=8)) {
                	  sixtherror.setVisible(false);
                	  flag=1;
  				}
              }
          });
        
       
        JLabel lblPasswordConfirm = new JLabel("Confirm Password*");
       
        lblPasswordConfirm.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblPasswordConfirm.setBounds(500,350,200,45);
        frame.getContentPane().add(lblPasswordConfirm);

        passwordFieldConfirm = new JPasswordField();
        passwordFieldConfirm.setFont(new Font("Tahoma", Font.PLAIN, 32));
        passwordFieldConfirm.setBounds(700, 350, 230, 50);
        frame.getContentPane().add(passwordFieldConfirm);
       
      sevenerror = new JLabel("please enter same password");
        sevenerror.setForeground(Color.RED);
        sevenerror.setBounds(700, 400, 232, 14);
        frame.getContentPane().add(sevenerror);
        sevenerror.setVisible(false);
        
        
        Use use=new Use();
        
        passwordFieldConfirm.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
               
                if(( passwordFieldConfirm.getText() == null)) {
              	  sevenerror.setVisible(true);
              	  flag=0;
	                }
                if((passwordField.getText().length()<=8)&&(!matcher.matches())) {
              	  sevenerror.setVisible(false);
              	  flag=1;
				}
               
            }
        	@Override
        	public void keyReleased(KeyEvent e) {
        		if(passwordField.getText().equals(passwordFieldConfirm.getText())) {
					 sevenerror.setVisible(false);
//					 valid();
	                }
        		else {
        			sevenerror.setText("password mismatch");
        			sevenerror.setVisible(true);
        		}
        		if((passwordField.toString().length()>=8)&&(passwordField.getText().equals(passwordFieldConfirm.getText()))&&(lastname.getText().toString()!=null)&&(use.name(firstname.getText())==1)&&(mobilenumber.getText().length() == 10)&&(need==0)) {
        			btnNewButton.setEnabled(true);
        			
        		}
        		else {
        			 btnNewButton.setEnabled(false);
        		}
        	}
        	
        });
        passwordFieldConfirm.addFocusListener(new FocusAdapter() {
        	@Override
        	public void focusLost(FocusEvent e) {
        		error();
        		if(!passwordField.getText().equals(passwordFieldConfirm.getText())) {

					 sevenerror.setVisible(true);
					  Border border = BorderFactory.createLineBorder(Color.RED, 1);
					  passwordFieldConfirm.setBorder(border);
					  sixtherror.setForeground(Color.red);
					 
	                }
        		if(passwordField.getText().equals(passwordFieldConfirm.getText())) {
        			sevenerror.setVisible(false);
        			Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
   				 passwordFieldConfirm.setBorder(border);
        		}
        	}
        	@Override
        	public void focusGained(FocusEvent e) {
        		if((passwordField.toString().length()>=8)&&(passwordField.getText().equals(passwordFieldConfirm.getText()))&&(lastname.getText().toString()!=null)&&(use.name(firstname.getText())==1)&&(mobilenumber.getText().length() == 10)&&(need==0)) {
        			btnNewButton.setEnabled(true);
        			
        		}
        		else {
        			 btnNewButton.setEnabled(false);
        		}
        	}
        });
      

       
        btnNewButton = new JButton("Register");
        btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 22));
        btnNewButton.setBounds(364, 564, 259, 74);
        frame.getContentPane().add(btnNewButton);
        btnNewButton.setEnabled(false);
        
        JButton reset = new JButton("Reset");
        reset.setFont(new Font("Tahoma", Font.PLAIN, 22));
        reset.setBounds(700, 564, 236, 74);
        frame.getContentPane().add(reset);
        reset.setEnabled(true);
        
        JButton btnNewButton_1 = new JButton("Sign in");
        btnNewButton_1.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		frame.dispose();
        		initializeLogin();
        		
        	}
        });
        btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 22));
        btnNewButton_1.setBounds(1059, 564, 220, 74);
        frame.getContentPane().add(btnNewButton_1);
       

        	
        reset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	
        	    firstname.setText(null);
        	    lastname.setText(null);
        	    middlename.setText(null);
        	    email.setText(null);
        	    mobilenumber.setText(null);
        	   
        	     city.setText(null);
        	     pincode.setText(null);
        	     country.setText(null);
        	     passwordField.setText(null);
        	     passwordFieldConfirm.setText(null);
        	     
        	     Border border = BorderFactory.createLineBorder(Color.BLACK, 1);
        	     firstname.setBorder(border);
        	     lastname.setBorder(border);
         	     email.setBorder(border);
         	     mobilenumber.setBorder(border);
         	     passwordField.setBorder(border);
         	     passwordFieldConfirm.setBorder(border);
         	    
         	     
         	     firsterror.setVisible(false);
         	     seconderror.setVisible(false);
         	     thirderror.setVisible(false);
         	     fourtherror.setVisible(false);
         	     sixtherror.setVisible(false);
         	     sevenerror.setVisible(false);
         	     
         	     
         	     
        	     btnNewButton.setEnabled(false);

            }
            });

	
    
        try {
                btnNewButton.addMouseListener(new MouseAdapter() {
                	@Override
                	public void mouseClicked(MouseEvent e) {
                		  user.setFirstname(firstname.getText());
                          user.setMiddlename(middlename.getText());
                          user.setLastname(lastname.getText());
                          user.setEmailid(email.getText());
                          user.setGender(gender.isSelected()?"Male":"Female");
                          user.setMobilenumber(mobilenumber.getText());
                          
                          
                          add.setEmailid(email.getText());
                          add.setCity(city.getText());
                          add.setState(state.getSelectedItem().toString());
                          add.setPincode(pincode.getText());
                          add.setCountry(country.getText());
                          
                          valid.setEmailid(email.getText());
                          valid.setPassword(passwordField.getText());
                          valid.setConfirm( passwordFieldConfirm.getText());
                          

                          System.out.println(user);
                          registerservice.saveData(user,add,valid);
                          UIManager.put("OptionPane.minimumSize",new Dimension(300,200)); 
                        JOptionPane.showMessageDialog(lblPasswordConfirm, "Registered Successfully");
                          frame.dispose();
                  		initializeLogin();
                	  }
                });

      }
      catch(Exception e) {
    	  e.printStackTrace();
      }
      
  
 
}
	protected void error() {
		// TODO Auto-generated method stub
		Border border1 = BorderFactory.createLineBorder(Color.BLACK, 1);
		firstname.setBorder(border1);
	     lastname.setBorder(border1);
	     email.setBorder(border1);
	     mobilenumber.setBorder(border1);
	     passwordField.setBorder(border1);
	     passwordFieldConfirm.setBorder(border1);
	    
	     firsterror.setVisible(false);
	     seconderror.setVisible(false);
	     thirderror.setVisible(false);
	     fourtherror.setVisible(false);
	     sixtherror.setVisible(false);
	     sevenerror.setVisible(false);
		
	}

	void initializeLogin() {
		frame = new JFrame();
		Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\Training\\Desktop\\avatar1.png");  
		frame.setIconImage(icon); 
		frame.getContentPane().setBackground(Color.getHSBColor(188, 66, 93));
		frame.setVisible(true);
		frame.setBounds(100, 100, 1000, 647);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
	
		JLabel lblNewLabel = new JLabel("Email Id");
		lblNewLabel.setFont(new Font("Tahoma",Font.PLAIN,18));
		lblNewLabel.setBounds(324, 148, 92, 26);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(465, 143, 152, 31);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		 textField.addKeyListener(new KeyAdapter() {
             @Override
             public void keyTyped(KeyEvent e) {
                 char c=e.getKeyChar();
                 if(textField.getText().length()>=50) {
                     e.consume();
                 }
             }
   	  	
         });
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setFont(new Font("Tahoma",Font.PLAIN,18));
		lblNewLabel_1.setBounds(324, 208, 92, 26);
		frame.getContentPane().add(lblNewLabel_1);
		
		passwordFieldLogin = new JPasswordField();
        passwordFieldLogin.setFont(new Font("Tahoma", Font.PLAIN, 32));
        passwordFieldLogin.setBounds(465,208 , 152, 31);
        frame.getContentPane().add(passwordFieldLogin);
        
        Button button = new Button("Sign in");
        button.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		int flag=0;
        		 try {
        			 
        			 if((textField.getText().length()==0)||(passwordFieldLogin.getText().length()==0)) {
        				 JOptionPane.showMessageDialog(button, "Enter Username & Password");
        			 }
        			
        			
        			 valid.setEmailid(textField.getText());
        			 valid.setPassword(passwordFieldLogin.getText());
        			 System.out.println(valid);
        			if(registerservice.authenticate(valid)&&(textField.getText().toString()!=null)) {
        				System.out.println("Logged in");
        				frame.dispose();
        				initializeSecond();
        				
        			}
        			else {
        				  JOptionPane.showMessageDialog(button, "Wrong Email & Password");
        			}
				} 
        		 catch (Exception e1) {
					// TODO Auto-generated catch block
					
				}

        	}
        });
        button.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        button.setBounds(465,289 , 152, 31);
        
        frame.getContentPane().add(button);

      
        
        JLabel lblNewLabel_2 = new JLabel("Create an account?");
        lblNewLabel_2.setFont(new Font("Tahoma",Font.PLAIN,18));
        lblNewLabel_2.setForeground(Color.RED);
        lblNewLabel_2.setBounds(324, 386, 181, 26);
        frame.getContentPane().add(lblNewLabel_2);
        
        JLabel lblNewLabel_3 = new JLabel("<HTML><U>Click here</U></HTML>");
        lblNewLabel_3.setFont(new Font("Tahoma",Font.PLAIN,18));
        lblNewLabel_3.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		frame.dispose();
        		initialize();
        	}
        });
        lblNewLabel_3.setBounds(498, 386, 86, 26);
        frame.getContentPane().add(lblNewLabel_3);
        
        
        JLabel lblNewLabel_4 = new JLabel("Sign In ");

        
        lblNewLabel_4.setBounds(400, 42, 143, 42);
        lblNewLabel_4.setFont(new Font("Tahoma",Font.PLAIN,30));
        frame.getContentPane().add(lblNewLabel_4);


	}
	private void initializeLand() {
		frame = new JFrame();
//		Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\Training\\Desktop\\avatar1.png");  
//		frame.setIconImage(icon);  
		frame.setVisible(true);
		frame.setBounds(100, 100, 952, 634);
		frame.getContentPane().setBackground(Color.getHSBColor(188, 66, 93));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.getContentPane().setLayout(null);
		

		JLabel lblNewLabel = new JLabel("User Management System");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 40));
		lblNewLabel.setBounds(252, 59, 500, 78);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Register");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				initialize();
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(253, 223, 166, 63);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Sign in");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				initializeLogin();
			}
		});

		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_1.setBounds(503, 223, 178, 63);
		frame.getContentPane().add(btnNewButton_1);
	}
private void initializeSecond() {
		
		frame = new JFrame();
		Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\Training\\Desktop\\avatar1.png"); 
		frame.getContentPane().setBackground(Color.getHSBColor(188, 66, 93));
		frame.setIconImage(icon);
		frame.setVisible(true);
		frame.setBounds(100, 100, 953, 689);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
		
		JButton btnNewButton_3 = new JButton("Logout");
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				initializeLand();
			}
		});
		btnNewButton_3.setBounds(782, 82, 101, 43);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton = new JButton("Edit");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				frame.dispose();
				initializeEdit();
			}
		});
		btnNewButton.setBounds(65, 87, 107, 38);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Show Details");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("Search Pressed");
				String firstname= "";
				String lastname = "";
				String middlename = "";
				String emailid="";
				String mobilenumber="";
				String gender="";
				Optional<User> user=registerservice.search(valid.getEmailid());
				firstname = user.get().getFirstname();
				System.out.println(firstname);
				middlename= user.get().getMiddlename();
				lastname = user.get().getLastname(); 
				emailid=user.get().getEmailid();
				mobilenumber = user.get().getMobilenumber(); 
				gender= user.get().getGender();
				model.addRow(new Object[]{firstname, middlename, lastname,emailid,mobilenumber,gender});
			}
		});
		btnNewButton_1.setBounds(288, 89, 150, 36);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("delete");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int res = JOptionPane.showConfirmDialog(frame,"Sure? You want to Delete?", "Delete Confirmation",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE);
                     if(res == JOptionPane.YES_OPTION){
                         registerservice.deleteData(valid);
                         frame.dispose();
                         initializeLand();
                     }else
                     {
                          JOptionPane.showMessageDialog(null, "You have selected NO");
                     }
			}
		});
		btnNewButton_2.setBounds(546, 87, 95, 38);
		frame.getContentPane().add(btnNewButton_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(65, 221, 836, 362);
		frame.getContentPane().add(scrollPane);
		
		
		model = new DefaultTableModel();
		table = new JTable();
		table.setBackground(new Color(176, 224, 230));
		scrollPane.setViewportView(table);
		model=new DefaultTableModel();
		Object[] columnNames = {"firstname", "lastname", "middlename","emailid","mobilenumber","gender"};
		Object[] row=new Object[0];
		model.setColumnIdentifiers(columnNames);
		table.setModel(model);

		
	}

	void initializeEdit() {
		frame = new JFrame();
		Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\Training\\Desktop\\avatar1.png");  
		frame.setIconImage(icon); 
		frame.getContentPane().setBackground(Color.getHSBColor(188, 66, 93));
		frame.setVisible(true);
		frame.setBounds(100, 100, 951, 649);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("First Name*");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel.setBounds(241, 125, 101, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Middle Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(241, 175, 141, 20);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Last Name*");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(241, 230, 121, 20);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Mobile Number*");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_3.setBounds(241, 278, 141, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		JTextField textField0 = new JTextField();
		 textField0.addKeyListener(new KeyAdapter() {
        	@Override
        	public void keyTyped(KeyEvent e) {
        		char c=e.getKeyChar();
                if((Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE)|| c==KeyEvent.VK_DELETE|| textField0.getText().length()>=25)) {
                    e.consume();
                }
        	}
        });
		textField0.setBounds(392, 122, 159, 23);
		frame.getContentPane().add(textField0);
		textField0.setColumns(10);
		
		JTextField textField_1 = new JTextField();
		 textField_1.addKeyListener(new KeyAdapter() {
	        	@Override
	        	public void keyTyped(KeyEvent e) {
	        		char c=e.getKeyChar();
	                if((Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE)|| c==KeyEvent.VK_DELETE|| textField_1.getText().length()>=25)) {
	                    e.consume();
	                }
	        	}
	        });
		textField_1.setBounds(392, 175, 159, 23);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JTextField textField_2 = new JTextField();
		 textField_2.addKeyListener(new KeyAdapter() {
	        	@Override
	        	public void keyTyped(KeyEvent e) {
	        		char c=e.getKeyChar();
	                if((Character.isDigit(c) || (c==KeyEvent.VK_BACK_SPACE)|| c==KeyEvent.VK_DELETE|| textField_2.getText().length()>=25)) {
	                    e.consume();
	                }
	        	}
	        });
		textField_2.setBounds(392, 227, 159, 23);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JTextField textField_3 = new JTextField();
		 textField_3.addKeyListener(new KeyAdapter() {
	        	@Override
	        	public void keyTyped(KeyEvent e) {
	        		char c=e.getKeyChar();
	                if((textField_3.getText().length()>10)) {
	                    e.consume();
	                }
	        	}
	        });
		textField_3.setBounds(392, 275, 159, 23);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		user=registerservice.getUser(textField.getText());
		textField0.setText(user.getFirstname());
		textField_1.setText(user.getLastname());
		textField_2.setText(user.getMiddlename());
		textField_3.setText(user.getMobilenumber());
		
		JButton btnNewButton = new JButton("Update");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				user.setEmailid(textField.getText());
				user.setFirstname(textField0.getText());
                user.setMiddlename(textField_2 .getText());
                user.setLastname(textField_1.getText());
                user.setMobilenumber(textField_3 .getText());
                registerservice.saveUpdate(user);
                JOptionPane.showMessageDialog(textField_2, "Updated Successfully");
                frame.dispose();
                initializeSecond();
			}
		});

		btnNewButton.setBounds(392, 347, 159, 36);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_4 = new JLabel("Edit Form");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel_4.setBounds(392, 46, 149, 28);
		frame.getContentPane().add(lblNewLabel_4);
	}

}

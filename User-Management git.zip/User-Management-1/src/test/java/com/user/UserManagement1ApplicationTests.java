package com.user;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.user.frontend.Use;


//@SpringBootTest
class UserManagement1ApplicationTests {

	@Test
	void contextLoads() {
	}
	@Test
	void test() {

		Use obj=new Use();
		int output=obj.name("thrinath");
		assertEquals(1,output);


	}
	
	@Test
	void test1() {
		Use obj=new Use();
		int output=obj.name("kiran");
		assertEquals(1,output);
		int output1=obj.name("");
		assertEquals(0,output1);
	
	}
	@Test
	void test2() {

		Use obj=new Use();
		int output=obj.lastname("thota");
		assertEquals(1,output);
		int output1=obj.name("");
		assertEquals(0,output1);
		 
	
	}
	@Test
	void test3() {

		Use obj=new Use();
		int output=obj.phone("9234567890");
		assertEquals(1,output);
		int output1=obj.phone("");
		assertEquals(0,output1);
		 
	
	}
	
	@Test
	void test4() {

		Use obj=new Use();
		int output=obj.pincode("555555");
		assertEquals(1,output);
		int output1=obj.pincode("1234");
		assertEquals(0,output1);
		 
	
	}
	@Test
	void test5() {

		Use obj=new Use();
		int output=obj.phone("9236666600");
		assertEquals(1,output);
		int output1=obj.phone("");
		assertEquals(0,output1);
		 
	
	}


	@Test
	void test6() {

		Use obj=new Use();
		int output=obj.pincode("55555");
		assertEquals(0,output);
		int output1=obj.pincode("1234");
		assertEquals(0,output1);
		 
	
	}
	
	@Test
	void test7() {

		Use obj=new Use();
		int output=obj.password("55555555");
		assertEquals(1,output);
		int output1=obj.password("1234");
		assertEquals(0,output1);
	} 
	@Test
	void test8() {

		Use obj=new Use();
		int output=obj.confirm("55555","55555");
		assertEquals(1,output);
		int output1=obj.confirm("12345","1234");
		assertEquals(0,output1);
		 
	
	}
	
}

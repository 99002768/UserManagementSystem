package com.user;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import com.user.model.Valid;

@SpringBootApplication
public class UserManagementApplication {

	public static void main(String[] args) {
//		SpringApplication.run(UserManagementApplication.class, args);
		SpringApplicationBuilder builder = new SpringApplicationBuilder(UserManagementApplication.class);
		builder.headless(false);

		ConfigurableApplicationContext context = builder.run(args);
	}
	@Bean
	public Valid create() {
		return new Valid();
	}
}

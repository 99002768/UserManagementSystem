package com.user.frontend;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.user.model.User;
import com.user.model.Valid;
import com.user.service.RegisterService;

@Service
public class SearchResult implements ActionListener{
	JFrame frame, frame1;
	JTextField textbox;
	JLabel lblEmail;
	JButton button;
	JPanel panel;
	String emailid=new String();
	static JTable table;

	@Autowired(required=true)
	RegisterService registerService;
	
	public SearchResult() {
		super();
		// TODO Auto-generated constructor stub
	}	
	public SearchResult(String emailid) {
		this.emailid=emailid;
		showTableData();
	}
	//String driverName = "com.mysql.jdbc.Driver";
	//String url = "jdbc:mysql://localhost:3333/project";
	//String userName = "root";
	//String password = "password";
	String[] columnNames = {"firstname", "lastname", "middlename","emailid","mobilenumber","gender"};
	//private JLabel lblNewLabel;
	//private JTextField passwd;
	
	public void createUI()
	{
		frame = new JFrame("Database Search Result");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		//textbox = new JTextField();
		//textbox.setBounds(120,30,150,20); 
		//lblEmail = new JLabel("Email");
		//lblEmail.setBounds(10, 30, 100, 20);
		//button = new JButton("search");
		//button.setBounds(120,130,150,20);
		//button.addActionListener(this);
		//
		//frame.getContentPane().add(textbox);
		//frame.getContentPane().add(lblEmail);
		//frame.getContentPane().add(button);
		//
		//lblNewLabel = new JLabel("password");
		//lblNewLabel.setBounds(10, 83, 46, 14);
		//frame.getContentPane().add(lblNewLabel);
		//
		//passwd = new JTextField();
		//passwd.setBounds(120, 80, 150, 20);
		//frame.getContentPane().add(passwd);
		//passwd.setColumns(10);
		//frame.setVisible(true);
		//frame.setSize(500, 400); 
	
	} 
	
	//public void actionPerformed(ActionEvent ae)
	//{
	//button = (JButton)ae.getSource();
	//System.out.println("Showing Table Data.......");
	 
	//} 
	
	public void showTableData()
	{
		System.out.println("hello");
		frame1 = new JFrame("Database Search Result");
		frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame1.getContentPane().setLayout(new BorderLayout()); 
		//TableModel tm = new TableModel();
		DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(columnNames);
		//DefaultTableModel model = new DefaultTableModel(tm.getData1(), tm.getColumnNames()); 
		//table = new JTable(model);
		table = new JTable();
		table.setModel(model); 
		table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		table.setFillsViewportHeight(true);
		JScrollPane scroll = new JScrollPane(table);
		scroll.setHorizontalScrollBarPolicy(
		JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		scroll.setVerticalScrollBarPolicy(
		JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED); 
		

		//String textvalue = textbox.getText().toString();
		//System.out.println(textvalue);
		int id;
		String firstname= "";
		String lastname = "";
		String middlename = "";
		String emailid="";
		String mobilenumber="";
		String gender="";
	
	//try
	//{ 
		//Class.forName(driverName); 
		//Connection con = DriverManager.getConnection(url, userName, password);
		//String sql = "select * from entiree where email = ?";
		//PreparedStatement ps = con.prepareStatement(sql);
		//ps.setString(1, textvalue);
		//ResultSet rs = ps.executeQuery();
		//int rs=0;
		//int i =0;
		//if(rs)
		//{
		//id = rs.getInt("id");
		//firstname = rs.getString("firstname");
		//middlename= rs.getString("middlename");
		//lastname = rs.getString("lastname"); 
		//emailid=rs.getString("emailid");
		//mobilenumber = rs.getString("mobilenumber"); 
		//gender= rs.getString("gender"); 
		//
		//
		//model.addRow(new Object[]{id,firstname, middlename, lastname,emailid,mobilenumber,gender});
		//i++; 
		//}
	//		if(i <1)
	//		{
	//			JOptionPane.showMessageDialog(null, "No Record Found","Error",
	//			JOptionPane.ERROR_MESSAGE);
	//		}
	//		if(i ==1)
	//		{
	//			System.out.println(i+" Record Found");
	//		}
	//		else
	//		{
	//			System.out.println(i+" Records Found");
	//		}
	//	}
	//	catch(Exception ex)
	//	{
	//	JOptionPane.showMessageDialog(null, ex.getMessage(),"Error",
	//	JOptionPane.ERROR_MESSAGE);
	//	}
		User user= registerService.search(emailid).orElseThrow();
		System.out.println("Here");
		if(user!= null) {	
			System.out.println("Found");
			firstname = user.getFirstname();
			middlename= user.getMiddlename();
			lastname = user.getLastname(); 
			emailid=user.getEmailid();
			mobilenumber = user.getMobilenumber(); 
			gender= user.getGender();
			model.addRow(new Object[]{firstname, middlename, lastname,emailid,mobilenumber,gender});
			
		}
		else {
			System.out.println("Not Found");
			JOptionPane.showMessageDialog(null, "No Record Found","Error",
					JOptionPane.ERROR_MESSAGE);
		}
		frame1.getContentPane().add(scroll);
		frame1.setVisible(true);
		frame1.setSize(400,300);
	}
	
	public static void main(String args[])
	{
	SearchResult sr = new SearchResult(null);
	sr.createUI(); 
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	

}
